package dev.fruchtwelt;

import com.destroystokyo.paper.profile.PlayerProfile;
import dev.fruchtwelt.api.NpcHealEvent;
import io.papermc.paper.datacomponent.item.ResolvableProfile;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Mannequin;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;

/**
 * NPCs mit Spieler-Skins (Mannequins): Patienten, Händler, Polierer, Scam-Händler, Schwarzmarkt und Shop.
 * Die City wird automatisch bevölkert; kranke Patienten tauchen außerdem in normalen Dörfern auf.
 * Alle NPCs werden nach jedem Neustart neu erzeugt und bekommen dabei zufällige Skins.
 */
public final class NpcManager implements Listener {

    public static final List<String> TYPES = List.of("patient", "shop", "haendler", "polierer", "scam", "schwarzmarkt", "dealer");

    public record Disease(String id, String name, List<String> cures, long reward) {
    }

    /** Laufzeit-Daten eines NPCs. */
    private static final class Npc {
        UUID entity;
        String role;            // z. B. "patient#3", "dealer:mais", "polierer"
        String type;            // patient, shop, haendler, polierer, scam, schwarzmarkt, dealer
        String dealerId;        // bei dealer: Substanz-ID
        String name;
        String personality;
        Location home;
        Location target;
        long pauseUntil;
        boolean village;
        long expires;           // Dorf-Patienten verschwinden irgendwann
    }

    private final FruchtweltPlugin plugin;
    private final NamespacedKey keyType;
    private final Map<String, Disease> diseases = new LinkedHashMap<>();
    private final Map<String, Npc> byRole = new LinkedHashMap<>();
    private final Map<UUID, Npc> byEntity = new HashMap<>();
    private final Map<UUID, String> sick = new HashMap<>();
    private final Map<String, Long> talkCooldown = new HashMap<>();
    private final Map<String, PlayerProfile> profiles = new ConcurrentHashMap<>();
    private final List<BukkitTask> tasks = new ArrayList<>();
    private int villageCounter;
    /** Gelöschte City-Rollen: kommen nicht automatisch zurück (gespeichert in npcs.yml). */
    private final Set<String> removedRoles = new LinkedHashSet<>();

    public NpcManager(FruchtweltPlugin plugin) {
        this.plugin = plugin;
        keyType = new NamespacedKey(plugin, "npc");
    }

    public void load() {
        loadRemoved();
        diseases.clear();
        ConfigurationSection c = plugin.getConfig().getConfigurationSection("npcs.diseases");
        if (c != null) {
            for (String id : c.getKeys(false)) {
                List<String> cures = new ArrayList<>();
                for (String f : c.getStringList(id + ".cures")) {
                    if (plugin.fruits().get(f) == null && plugin.items().other(f) == null) {
                        plugin.getLogger().warning("npcs.diseases." + id + ": unbekanntes Heilmittel " + f);
                    } else cures.add(f.toLowerCase(Locale.ROOT));
                }
                if (!cures.isEmpty()) diseases.put(id, new Disease(id, c.getString(id + ".name", id), cures, c.getLong(id + ".reward", 10)));
            }
        }
        stop();
        long sickPeriod = Math.max(1, plugin.getConfig().getLong("npcs.sick-check-minutes", 3)) * 60 * 20;
        tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, this::sicknessTick, 200L, sickPeriod));
        tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, this::cityTick, 60L, 200L));
        tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, this::walkTick, 40L, 2L));
        tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, this::ambientTick, 100L, 60L));
        long villagePeriod = Math.max(1, plugin.getConfig().getLong("villages.check-minutes", 5)) * 60 * 20;
        tasks.add(Bukkit.getScheduler().runTaskTimer(plugin, this::villageTick, 600L, villagePeriod));
    }

    public void stop() {
        for (BukkitTask t : tasks) t.cancel();
        tasks.clear();
    }

    /** Alle NPCs entfernen (beim Abschalten oder für einen kompletten Neuaufbau). */
    public void removeAll() {
        for (Npc n : new ArrayList<>(byEntity.values())) {
            Entity e = Bukkit.getEntity(n.entity);
            if (e != null) e.remove();
        }
        byEntity.clear();
        byRole.clear();
        sick.clear();
    }

    public String typeOf(Entity e) {
        return e.getPersistentDataContainer().get(keyType, PersistentDataType.STRING);
    }

    public World cityWorld() {
        return Bukkit.getWorld(plugin.getConfig().getString("city.world", "Drug_City"));
    }

    public Location cityCenter() {
        World w = cityWorld();
        if (w == null) return null;
        Location p = parse(w, plugin.getConfig().getString("city.center", ""));
        return p != null ? p : w.getSpawnLocation();
    }

    // ------------------------------------------------------------------ Erzeugen

    private Npc spawnNpc(Location loc, String role, String type, String dealerId, String name, boolean village) {
        Npc n = new Npc();
        n.role = role;
        n.type = type;
        n.dealerId = dealerId;
        n.name = name;
        n.personality = plugin.dialogue().randomPersonality();
        n.home = loc.clone();
        n.village = village;
        Mannequin m = loc.getWorld().spawn(loc, Mannequin.class, (Consumer<Mannequin>) e -> {
            e.setPersistent(false);
            e.setInvulnerable(true);
            e.setCollidable(false);
            e.setCustomNameVisible(true);
            e.getPersistentDataContainer().set(keyType, PersistentDataType.STRING, type);
        });
        n.entity = m.getUniqueId();
        byEntity.put(n.entity, n);
        byRole.put(role, n);
        applySkin(m);
        refreshName(n);
        return n;
    }

    /** Zufälligen Skin aus der Liste setzen; das Laden bei Mojang passiert im Hintergrund. */
    private void applySkin(Mannequin m) {
        List<String> skins = plugin.getConfig().getStringList("npcs.skins");
        if (skins.isEmpty()) return;
        String skin = skins.get(ThreadLocalRandom.current().nextInt(skins.size()));
        PlayerProfile cached = profiles.get(skin.toLowerCase(Locale.ROOT));
        if (cached != null) {
            setProfile(m, cached);
            return;
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            PlayerProfile profile = Bukkit.createProfile(skin);
            try {
                profile.complete(true);
            } catch (Throwable ignored) {
                // offline oder Name unbekannt: dann bleibt der Standard-Skin
            }
            if (profile.hasTextures()) profiles.put(skin.toLowerCase(Locale.ROOT), profile);
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (m.isValid() && profile.hasTextures()) setProfile(m, profile);
            });
        });
    }

    private void setProfile(Mannequin m, PlayerProfile profile) {
        try {
            m.setProfile(ResolvableProfile.resolvableProfile(profile));
        } catch (Throwable t) {
            plugin.getLogger().fine("Skin konnte nicht gesetzt werden: " + t.getMessage());
        }
    }

    private void refreshName(Npc n) {
        Entity e = Bukkit.getEntity(n.entity);
        if (e == null) return;
        String name = Text.esc(n.name);
        String template;
        if (n.type.equals("patient") && sick.containsKey(n.entity)) {
            template = Text.fill(plugin.text().raw("npc-name-sick"), "name", name);
        } else if (n.type.equals("dealer")) {
            Fruits.Def d = plugin.fruits().get(n.dealerId);
            template = Text.fill(plugin.text().raw("npc-name-dealer"), "name", name, "item", d == null ? n.dealerId : d.name);
        } else {
            template = Text.fill(plugin.text().raw("npc-name-" + n.type), "name", name);
        }
        e.customName(Text.mm(template));
    }

    public String randomName() {
        List<String> names = plugin.getConfig().getStringList("npcs.names");
        if (names.isEmpty()) return "Bürger";
        return names.get(ThreadLocalRandom.current().nextInt(names.size()));
    }

    // ------------------------------------------------------------------ City

    /** Hält die City voll: alle Rollen vorhanden, Schwarzmarkt nur nachts. */
    private void cityTick() {
        World w = cityWorld();
        if (w == null || !plugin.getConfig().getBoolean("city.enabled", true)) return;
        if (w.getPlayers().isEmpty()) return;
        Location center = cityCenter();
        boolean night = w.getTime() >= 13000 && w.getTime() <= 23000;
        Map<String, String[]> wanted = wantedRoles(night);
        wanted.keySet().removeAll(removedRoles);
        // Nicht mehr gewollte entfernen (z. B. Schwarzmarkt am Tag); von Admins gesetzte NPCs bleiben
        for (Npc n : new ArrayList<>(byRole.values())) {
            if (n.village || n.role.startsWith("admin#") || wanted.containsKey(n.role)) continue;
            remove(n);
        }
        List<Location> points = points(w);
        int pointIndex = ThreadLocalRandom.current().nextInt(Math.max(1, points.size()));
        for (Map.Entry<String, String[]> e : wanted.entrySet()) {
            Npc existing = byRole.get(e.getKey());
            if (existing != null && Bukkit.getEntity(existing.entity) != null) continue;
            if (existing != null) forget(existing);
            String type = e.getValue()[0];
            Location loc;
            if (!points.isEmpty() && !type.equals("patient")) {
                loc = points.get(pointIndex++ % points.size());
            } else {
                loc = randomSpot(center, plugin.getConfig().getInt("city.radius", 60));
            }
            if (loc == null) continue;
            String name = e.getValue()[2] != null ? e.getValue()[2] : randomName();
            spawnNpc(loc, e.getKey(), type, e.getValue()[1], name, false);
        }
    }

    /** Rolle -> {typ, dealerId, fester Name}. */
    private Map<String, String[]> wantedRoles(boolean night) {
        Map<String, String[]> r = new LinkedHashMap<>();
        ConfigurationSection c = plugin.getConfig().getConfigurationSection("city.npcs");
        int patients = plugin.getConfig().getInt("city.patients", 15);
        for (int i = 0; i < patients; i++) r.put("patient#" + i, new String[]{"patient", null, null});
        if (c == null || c.getBoolean("shop", true)) r.put("shop", new String[]{"shop", null, plugin.getConfig().getString("city.names.shop", "Heiler-Meister")});
        if (c == null || c.getBoolean("haendler", true)) r.put("haendler", new String[]{"haendler", null, null});
        if (c == null || c.getBoolean("polierer", true)) r.put("polierer", new String[]{"polierer", null, plugin.getConfig().getString("city.names.polierer", "Juwelier Kalle")});
        if (c == null || c.getBoolean("scam", true)) r.put("scam", new String[]{"scam", null, null});
        if ((c == null || c.getBoolean("schwarzmarkt", true)) && night) r.put("schwarzmarkt", new String[]{"schwarzmarkt", null, null});
        if (c == null || c.getBoolean("substance-dealers", true)) {
            for (String id : plugin.dealers().dealerItems()) r.put("dealer:" + id, new String[]{"dealer", id, null});
        }
        return r;
    }

    private List<Location> points(World w) {
        List<Location> out = new ArrayList<>();
        if (!plugin.getConfig().getString("city.mode", "random").equalsIgnoreCase("points")) return out;
        for (String s : plugin.getConfig().getStringList("city.points")) {
            Location l = parse(w, s);
            if (l != null) out.add(l);
        }
        java.util.Collections.shuffle(out);
        return out;
    }

    /** Alle City-NPCs neu würfeln (neue Plätze, neue Skins). */
    public void respawnCity() {
        for (Npc n : new ArrayList<>(byRole.values())) if (!n.village) remove(n);
        cityTick();
    }

    private void remove(Npc n) {
        Entity e = Bukkit.getEntity(n.entity);
        if (e != null) e.remove();
        forget(n);
    }

    private void forget(Npc n) {
        byEntity.remove(n.entity);
        byRole.remove(n.role);
        sick.remove(n.entity);
    }

    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent e) {
        // Reste aus alten Versionen oder vor einem Neustart entfernen
        for (Entity en : e.getEntities()) {
            if (typeOf(en) != null && !byEntity.containsKey(en.getUniqueId())) en.remove();
        }
    }

    // ------------------------------------------------------------------ Laufen

    private void walkTick() {
        boolean cityWander = plugin.getConfig().getBoolean("city.wander", true);
        double radius = plugin.getConfig().getDouble("city.wander-radius", 8);
        long now = System.currentTimeMillis();
        for (Npc n : new ArrayList<>(byEntity.values())) {
            Entity e = Bukkit.getEntity(n.entity);
            if (n.village && (e == null || !e.isValid())) {
                forget(n);
                continue;
            }
            boolean walks = n.type.equals("patient") || (cityWander && !n.type.equals("shop") && !n.type.equals("polierer"));
            if (!walks) continue;
            if (e == null || !e.isValid()) continue;
            if (n.village && n.expires > 0 && now > n.expires) {
                remove(n);
                continue;
            }
            if (now < n.pauseUntil) continue;
            Location cur = e.getLocation();
            for (Player p : e.getWorld().getPlayers()) {
                if (p.getLocation().distanceSquared(cur) < 6.25) {
                    face(e, p.getLocation());
                    n.pauseUntil = now + 1500;
                    break;
                }
            }
            if (now < n.pauseUntil) continue;
            if (n.target == null) {
                ThreadLocalRandom r = ThreadLocalRandom.current();
                double a = r.nextDouble() * Math.PI * 2, d = r.nextDouble() * radius;
                n.target = n.home.clone().add(Math.cos(a) * d, 0, Math.sin(a) * d);
            }
            boolean ill = sick.containsKey(n.entity);
            double speed = ill ? 0.07 : 0.14;
            double dx = n.target.getX() - cur.getX(), dz = n.target.getZ() - cur.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist < 0.4) {
                n.target = null;
                n.pauseUntil = now + ThreadLocalRandom.current().nextLong(ill ? 4000 : 2000, ill ? 10000 : 7000);
                continue;
            }
            double nx = cur.getX() + dx / dist * speed, nz = cur.getZ() + dz / dist * speed;
            Double y = ground(cur.getWorld(), nx, nz, cur.getY());
            if (y == null) {
                n.target = null;
                n.pauseUntil = now + 1000;
                continue;
            }
            Location next = new Location(cur.getWorld(), nx, y, nz);
            next.setYaw((float) Math.toDegrees(Math.atan2(-dx, dz)));
            next.setPitch(ill ? 25 : 0);
            e.teleport(next);
        }
    }

    private void face(Entity e, Location to) {
        Location l = e.getLocation();
        double dx = to.getX() - l.getX(), dz = to.getZ() - l.getZ();
        l.setYaw((float) Math.toDegrees(Math.atan2(-dx, dz)));
        e.teleport(l);
    }

    /** Begehbarer Boden nahe der aktuellen Höhe (max. 1 Block hoch oder 2 runter). */
    private Double ground(World w, double x, double z, double y) {
        int bx = (int) Math.floor(x), bz = (int) Math.floor(z), by = (int) Math.floor(y);
        if (!w.isChunkLoaded(bx >> 4, bz >> 4)) return null;
        for (int dy = 1; dy >= -2; dy--) {
            Block feet = w.getBlockAt(bx, by + dy, bz);
            Block below = feet.getRelative(0, -1, 0);
            Block head = feet.getRelative(0, 1, 0);
            if (below.getType().isSolid() && feet.isPassable() && head.isPassable() && !feet.isLiquid() && !below.isLiquid()) {
                return (double) (by + dy);
            }
        }
        return null;
    }

    private Location randomSpot(Location center, int radius) {
        if (center == null) return null;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (int tries = 0; tries < 15; tries++) {
            int x = center.getBlockX() + r.nextInt(-radius, radius + 1);
            int z = center.getBlockZ() + r.nextInt(-radius, radius + 1);
            Location l = safe(center.getWorld(), x, z);
            if (l != null) return l;
        }
        return null;
    }

    private Location safe(World w, int x, int z) {
        Block top = w.getHighestBlockAt(x, z);
        Material m = top.getType();
        if (top.isLiquid() || m == Material.LAVA || m.name().contains("LEAVES") || m == Material.CACTUS || !m.isSolid()) return null;
        return new Location(w, x + 0.5, top.getY() + 1, z + 0.5);
    }

    private static Location parse(World w, String s) {
        if (s == null || s.isBlank()) return null;
        String[] p = s.trim().split("[ ,]+");
        try {
            return new Location(w, Double.parseDouble(p[0]) + 0.5, Double.parseDouble(p[1]), Double.parseDouble(p[2]) + 0.5);
        } catch (Exception e) {
            return null;
        }
    }

    // ------------------------------------------------------------------ Dörfer

    /** Kranke Patienten in normalen Dörfern (überall, wo Dorfbewohner sind). */
    private void villageTick() {
        if (!plugin.getConfig().getBoolean("villages.enabled", true) || diseases.isEmpty()) return;
        List<String> worlds = plugin.getConfig().getStringList("villages.worlds");
        int minVillagers = plugin.getConfig().getInt("villages.min-villagers", 3);
        double chance = plugin.getConfig().getDouble("villages.chance", 0.5);
        int max = plugin.getConfig().getInt("villages.max-per-village", 2);
        long life = plugin.getConfig().getLong("villages.lifetime-minutes", 30) * 60_000L;
        World city = cityWorld();
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (Player p : Bukkit.getOnlinePlayers()) {
            World w = p.getWorld();
            if (w.equals(city)) continue;
            if (!worlds.isEmpty() && !worlds.contains(w.getName())) continue;
            List<Villager> villagers = new ArrayList<>();
            int patientsNear = 0;
            for (Entity e : w.getNearbyEntities(p.getLocation(), 64, 32, 64)) {
                if (e instanceof Villager v && typeOf(v) == null) villagers.add(v);
                if (typeOf(e) != null && "patient".equals(typeOf(e))) patientsNear++;
            }
            if (villagers.size() < minVillagers || patientsNear >= max || r.nextDouble() >= chance) continue;
            Villager v = villagers.get(r.nextInt(villagers.size()));
            Location base = v.getLocation();
            Double y = ground(w, base.getX() + 1.5, base.getZ(), base.getY());
            Location loc = y == null ? base : new Location(w, base.getX() + 1.5, y, base.getZ());
            Npc n = spawnNpc(loc, "village#" + (villageCounter++), "patient", null, randomName(), true);
            n.expires = System.currentTimeMillis() + life;
            List<Disease> list = new ArrayList<>(diseases.values());
            Entity e = Bukkit.getEntity(n.entity);
            if (e != null) makeSick(n, list.get(r.nextInt(list.size())));
        }
    }

    // ------------------------------------------------------------------ Krankheiten

    private void sicknessTick() {
        if (diseases.isEmpty()) return;
        List<Npc> healthy = new ArrayList<>();
        int sickCount = 0;
        for (Npc n : byEntity.values()) {
            if (!n.type.equals("patient") || n.village) continue;
            if (sick.containsKey(n.entity)) sickCount++;
            else healthy.add(n);
        }
        int max = plugin.getConfig().getInt("npcs.max-sick", 6);
        double chance = plugin.getConfig().getDouble("npcs.sick-chance", 0.6);
        int perTick = plugin.getConfig().getInt("npcs.new-sick-per-check", 2);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        List<Disease> list = new ArrayList<>(diseases.values());
        for (int i = 0; i < perTick && sickCount < max && !healthy.isEmpty(); i++) {
            if (r.nextDouble() >= chance) continue;
            makeSick(healthy.remove(r.nextInt(healthy.size())), list.get(r.nextInt(list.size())));
            sickCount++;
        }
    }

    private void makeSick(Npc n, Disease d) {
        sick.put(n.entity, d.id());
        refreshName(n);
    }

    public int makeAllSick() {
        if (diseases.isEmpty()) return 0;
        int c = 0;
        List<Disease> list = new ArrayList<>(diseases.values());
        for (Npc n : byEntity.values()) {
            if (!n.type.equals("patient") || sick.containsKey(n.entity)) continue;
            makeSick(n, list.get(ThreadLocalRandom.current().nextInt(list.size())));
            c++;
        }
        return c;
    }

    /** Kranke husten, niesen und reden leise vor sich hin, wenn jemand in der Nähe ist. */
    private void ambientTick() {
        long now = System.currentTimeMillis();
        for (Npc n : byEntity.values()) {
            if (!sick.containsKey(n.entity)) continue;
            Entity e = Bukkit.getEntity(n.entity);
            if (e == null) continue;
            Location head = e.getLocation().add(0, 1.6, 0);
            ThreadLocalRandom r = ThreadLocalRandom.current();
            e.getWorld().spawnParticle(Particle.DUST, head, 3, 0.25, 0.2, 0.25, 0,
                    new Particle.DustOptions(Color.fromRGB(150, 200, 90), 0.8f));
            if (r.nextDouble() < 0.35) {
                e.getWorld().spawnParticle(Particle.SNEEZE, head.clone().add(e.getLocation().getDirection().multiply(0.4)), 6, 0.1, 0.05, 0.1, 0.02);
                e.getWorld().playSound(e.getLocation(), r.nextBoolean() ? Sound.ENTITY_PANDA_SNEEZE : Sound.ENTITY_PLAYER_HURT, 0.5f, 1.4f);
            }
            for (Player p : e.getWorld().getPlayers()) {
                if (p.getLocation().distanceSquared(e.getLocation()) > 49) continue;
                String key = n.entity + "|" + p.getUniqueId() + "|amb";
                Long last = talkCooldown.get(key);
                if (last != null && now - last < 45_000) continue;
                talkCooldown.put(key, now);
                Disease d = diseases.get(sick.get(n.entity));
                say(n, p, plugin.dialogue().line(n.personality, "ambient", "player", p.getName(), "name", n.name,
                        "disease", d == null ? "" : Text.plain(d.name())));
            }
        }
    }

    /** NPC sagt etwas: kleine Sprechblase über dem Kopf und eine Chatzeile nur für den Spieler. */
    public void say(UUID entity, Player to, String text) {
        Npc n = byEntity.get(entity);
        if (n != null) say(n, to, text);
    }

    private void say(Npc n, Player to, String text) {
        if (text == null || text.isEmpty()) return;
        Entity e = Bukkit.getEntity(n.entity);
        to.sendMessage(Text.mm(Text.fill(plugin.text().raw("npc-chat"), "name", Text.esc(n.name), "text", text)));
        if (e == null || !plugin.getConfig().getBoolean("npcs.speech-bubbles", true)) return;
        TextDisplay bubble = e.getWorld().spawn(e.getLocation().add(0, 2.35, 0), TextDisplay.class, (Consumer<TextDisplay>) td -> {
            td.setPersistent(false);
            td.setBillboard(Display.Billboard.CENTER);
            td.text(Text.mm("<gray>" + text));
            td.setLineWidth(160);
            td.setBackgroundColor(Color.fromARGB(110, 0, 0, 0));
            td.setTransformation(new org.bukkit.util.Transformation(new org.joml.Vector3f(),
                    new org.joml.Quaternionf(), new org.joml.Vector3f(0.6f, 0.6f, 0.6f), new org.joml.Quaternionf()));
        });
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (bubble.isValid()) bubble.remove();
        }, 80L);
    }

    // ------------------------------------------------------------------ Klick

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEntityEvent e) {
        Npc n = byEntity.get(e.getRightClicked().getUniqueId());
        if (n == null) {
            if (typeOf(e.getRightClicked()) != null) e.setCancelled(true);
            return;
        }
        e.setCancelled(true);
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        switch (n.type) {
            case "shop" -> {
                say(n, p, plugin.dialogue().dealer("shop", "greet", "player", p.getName()));
                plugin.shop().openShop(p);
            }
            case "patient" -> patient(p, n);
            default -> plugin.dealers().open(p, n.entity, n.type, n.dealerId, n.name);
        }
    }

    private void patient(Player p, Npc n) {
        Disease d = diseases.get(sick.get(n.entity));
        PlayerStore.Data data = plugin.players().get(p.getUniqueId());
        String time = plugin.dialogue().timeOfDay(p.getWorld());
        String[] kv = {"player", p.getName(), "name", n.name, "time", time, "heals", String.valueOf(data.heals),
                "disease", d == null ? "" : Text.plain(d.name()), "cures", d == null ? "" : cureNames(d)};
        long now = System.currentTimeMillis();
        String key = n.entity + "|" + p.getUniqueId();
        boolean again = talkCooldown.containsKey(key) && now - talkCooldown.get(key) < 20_000;
        talkCooldown.put(key, now);
        if (d == null) {
            String mood = plugin.dialogue().moodSituation(p.getWorld());
            String line = mood != null ? plugin.dialogue().line(n.personality, mood, kv) : "";
            if (line.isEmpty()) line = plugin.dialogue().line(n.personality, data.heals >= 10 ? "healthy-hero" : "healthy", kv);
            say(n, p, line);
            return;
        }
        ItemStack hand = p.getInventory().getItemInMainHand();
        String held = plugin.items().idOf(hand);
        if (held == null || !d.cures().contains(held)) {
            String situation = again ? "again" : held != null ? "sick-wrong" : "sick-greet";
            say(n, p, plugin.dialogue().line(n.personality, situation, kv));
            plugin.text().actionBar(p, "npc-needs-short", "cures", cureNames(d));
            return;
        }
        if (p.getGameMode() != GameMode.CREATIVE) hand.setAmount(hand.getAmount() - 1);
        sick.remove(n.entity);
        refreshName(n);
        int tierBefore = plugin.shop().tierOf(data.heals);
        data.heals++;
        data.taler += d.reward();
        data.helpedNpcs++;
        plugin.players().markDirty();
        int tierAfter = plugin.shop().tierOf(data.heals);
        int heroMinutes = plugin.getConfig().getInt("npcs.hero-effect-minutes", 10);
        if (heroMinutes > 0) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.HERO_OF_THE_VILLAGE, heroMinutes * 60 * 20,
                    Math.max(0, plugin.getConfig().getInt("npcs.hero-effect-level", 1) - 1), true, true, true));
        }
        Entity e = Bukkit.getEntity(n.entity);
        if (e != null) {
            e.getWorld().spawnParticle(Particle.HEART, e.getLocation().add(0, 2, 0), 8, 0.4, 0.3, 0.4, 0);
            e.getWorld().playSound(e.getLocation(), Sound.ENTITY_VILLAGER_CELEBRATE, 1f, 1.2f);
        }
        say(n, p, plugin.dialogue().line(n.personality, "healed", kv));
        plugin.text().send(p, "npc-healed", "name", Text.esc(n.name), "money", plugin.shop().money(d.reward()),
                "heals", String.valueOf(data.heals));
        Bukkit.getPluginManager().callEvent(new NpcHealEvent(p.getUniqueId(), p.getName(), Text.plain(d.name()), data.heals, d.reward()));
        if (tierAfter > tierBefore) {
            String tierName = plugin.shop().tiers().get(tierAfter - 1).name();
            plugin.text().send(p, "shop-tier-unlocked", "tier", tierName);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            plugin.notifier().discord("shop-tier", "player", p.getName(), "tier", Text.plain(tierName), "heals", String.valueOf(data.heals));
        }
        if (n.village) n.expires = System.currentTimeMillis() + 20_000; // geht nach dem Dank nach Hause
    }

    private String cureNames(Disease d) {
        List<String> out = new ArrayList<>();
        for (String c : d.cures()) {
            Fruits.Def f = plugin.fruits().get(c);
            CustomItems.Other o = plugin.items().other(c);
            out.add(Text.plain(f != null ? f.name : o != null ? o.name : c));
        }
        return String.join(plugin.text().raw("npc-or"), out);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (typeOf(e.getEntity()) != null) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ Admin

    /** Admin: NPC an der eigenen Position erzeugen (bleibt bis zum Neustart). */
    public void adminSpawn(Player p, String type, String dealerId, String name) {
        String role = "admin#" + System.nanoTime();
        spawnNpc(p.getLocation(), role, type, dealerId, name == null ? randomName() : name, false);
    }

    // ------------------------------------------------------------------ Löschen

    /** Entfernt einen NPC; City-NPCs werden dabei gesperrt, damit sie nicht sofort wieder auftauchen. */
    private void removeForGood(Npc n) {
        if (!n.village && !n.role.startsWith("admin#")) removedRoles.add(n.role);
        remove(n);
    }

    /** Den angeschauten NPC löschen. */
    public boolean removeLookedAt(Player p) {
        Entity t = p.getTargetEntity(8);
        if (t == null) return false;
        Npc n = byEntity.get(t.getUniqueId());
        if (n == null) {
            if (typeOf(t) == null) return false;
            t.remove(); // Rest aus einer alten Version
            return true;
        }
        removeForGood(n);
        saveRemoved();
        return true;
    }

    /** Alle NPCs einer Art löschen: patient, shop, haendler, polierer, scam, schwarzmarkt, dealer, dorf, admin. */
    public int removeType(String type) {
        int count = 0;
        for (Npc n : new ArrayList<>(byEntity.values())) {
            boolean match = switch (type) {
                case "dorf" -> n.village;
                case "admin" -> n.role.startsWith("admin#");
                default -> n.type.equals(type) && !n.village;
            };
            if (!match) continue;
            removeForGood(n);
            count++;
        }
        // auch Rollen sperren, die gerade nicht da sind (z. B. Schwarzmarkt am Tag)
        if (!type.equals("dorf") && !type.equals("admin")) {
            for (Map.Entry<String, String[]> e : wantedRoles(true).entrySet()) {
                if (e.getValue()[0].equals(type)) removedRoles.add(e.getKey());
            }
        }
        saveRemoved();
        return count;
    }

    /** Einen Händler einer bestimmten Substanz löschen (dealer:<id>). */
    public int removeDealer(String id) {
        String role = "dealer:" + id.toLowerCase(Locale.ROOT);
        removedRoles.add(role);
        Npc n = byRole.get(role);
        int count = 0;
        if (n != null) {
            remove(n);
            count = 1;
        }
        saveRemoved();
        return count;
    }

    /** Alle NPCs im Umkreis löschen. */
    public int removeRadius(Location at, double radius) {
        int count = 0;
        for (Npc n : new ArrayList<>(byEntity.values())) {
            Entity e = Bukkit.getEntity(n.entity);
            if (e == null || !e.getWorld().equals(at.getWorld()) || e.getLocation().distance(at) > radius) continue;
            removeForGood(n);
            count++;
        }
        for (Entity e : at.getWorld().getNearbyEntities(at, radius, radius, radius)) {
            if (typeOf(e) != null && !byEntity.containsKey(e.getUniqueId())) {
                e.remove();
                count++;
            }
        }
        saveRemoved();
        return count;
    }

    /** NPCs nach Namen löschen (Teil des Namens reicht, Groß-/Kleinschreibung egal). */
    public int removeName(String name) {
        String q = name.toLowerCase(Locale.ROOT);
        int count = 0;
        for (Npc n : new ArrayList<>(byEntity.values())) {
            if (n.name == null || !n.name.toLowerCase(Locale.ROOT).contains(q)) continue;
            removeForGood(n);
            count++;
        }
        saveRemoved();
        return count;
    }

    /** Wirklich alle NPCs löschen (auch Reste in allen geladenen Welten); die City bleibt danach leer. */
    public int removeEverything() {
        int count = byEntity.size();
        for (Npc n : new ArrayList<>(byEntity.values())) removeForGood(n);
        removedRoles.addAll(wantedRoles(true).keySet());
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntities()) {
                if (typeOf(e) != null) {
                    e.remove();
                    count++;
                }
            }
        }
        saveRemoved();
        return count;
    }

    /** Gelöschte City-NPCs wieder zulassen; sie erscheinen beim nächsten City-Durchlauf. */
    public int restore() {
        int count = removedRoles.size();
        removedRoles.clear();
        saveRemoved();
        cityTick();
        return count;
    }

    /** Anzahl NPCs je Art, für /fw npc liste. */
    public Map<String, Integer> countByType() {
        Map<String, Integer> out = new TreeMap<>();
        for (Npc n : byEntity.values()) out.merge(n.village ? "dorf" : n.role.startsWith("admin#") ? "admin" : n.type, 1, Integer::sum);
        return out;
    }

    public int removedCount() {
        return removedRoles.size();
    }

    private File removedFile() {
        return new File(plugin.getDataFolder(), "npcs.yml");
    }

    private void loadRemoved() {
        removedRoles.clear();
        File f = removedFile();
        if (f.exists()) removedRoles.addAll(YamlConfiguration.loadConfiguration(f).getStringList("removed-roles"));
    }

    private void saveRemoved() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("removed-roles", new ArrayList<>(removedRoles));
        try {
            y.save(removedFile());
        } catch (IOException e) {
            plugin.getLogger().warning("npcs.yml konnte nicht gespeichert werden: " + e.getMessage());
        }
    }

    public int count() {
        return byEntity.size();
    }

    public int sickCount() {
        return sick.size();
    }

    public boolean isSick(UUID entity) {
        return sick.containsKey(entity);
    }

    public Map<String, Disease> diseases() {
        return diseases;
    }
}
