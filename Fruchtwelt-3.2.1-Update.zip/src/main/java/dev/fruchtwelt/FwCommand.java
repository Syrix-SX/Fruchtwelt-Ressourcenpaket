package dev.fruchtwelt;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** /fw – alle Befehle. */
public final class FwCommand implements TabExecutor {

    private final FruchtweltPlugin plugin;

    public FwCommand(FruchtweltPlugin plugin) {
        this.plugin = plugin;
    }

    private Text t() {
        return plugin.text();
    }

    @Override
    public boolean onCommand(@NotNull CommandSender s, @NotNull Command cmd, @NotNull String label, String @NotNull [] a) {
        String sub = a.length == 0 ? "hilfe" : a[0].toLowerCase(Locale.ROOT);
        boolean admin = s.hasPermission("fruchtwelt.admin");
        switch (sub) {
            case "buch" -> {
                if (s instanceof Player p) plugin.book().open(p);
            }
            case "taler", "geld" -> {
                if (a.length >= 2 && admin && !a[1].equalsIgnoreCase("info")) return money(s, a);
                if (s instanceof Player p) {
                    t().send(s, "cmd-money", "money", plugin.shop().money(plugin.players().get(p.getUniqueId()).taler));
                }
            }
            case "stats" -> stats(s, a);
            case "dm" -> {
                if (s instanceof Player p) dm(p, a);
            }
            case "saison" -> season(s);
            case "shop" -> {
                if (admin && s instanceof Player p) plugin.shop().openShop(p);
            }
            case "dashboard", "menu", "menü" -> {
                if (!(s instanceof Player p)) return true;
                if (a.length >= 2 && a[1].equalsIgnoreCase("admin")) plugin.dashboard().openAdmin(p);
                else plugin.dashboard().openPlayer(p);
            }
            case "einweisung", "tutorial", "hilfe2" -> {
                if (s instanceof Player p) plugin.dashboard().tutorial(p, a.length >= 2 ? parse(a[1], 1) : 1);
            }
            case "gruppe", "group" -> {
                if (s instanceof Player p) group(p, a);
            }
            case "city" -> {
                if (!(s instanceof Player p)) return true;
                if (a.length >= 2 && admin) {
                    switch (a[1].toLowerCase(Locale.ROOT)) {
                        case "punkt", "addpunkt" -> plugin.dashboard().addPoint(p);
                        case "respawn" -> {
                            plugin.npcs().respawnCity();
                            t().send(s, "admin-respawned");
                        }
                        default -> t().sendRaw(s, "<gray>/fw city [punkt|respawn]");
                    }
                    return true;
                }
                if (plugin.getConfig().getBoolean("city.teleport-command", true) || admin) plugin.dashboard().city(p);
            }
            case "miete", "rent" -> {
                if (s instanceof Player p) plugin.houses().rentCommand(p, a);
            }
            case "haus", "house" -> {
                if (s instanceof Player p) plugin.houses().houseCommand(p, a);
            }
            case "punkte", "points" -> {
                if (!admin) return noPerm(s);
                points(s, a);
            }
            case "give" -> {
                if (!admin) return noPerm(s);
                give(s, a);
            }
            case "heilungen" -> {
                if (!admin) return noPerm(s);
                heals(s, a);
            }
            case "distrikt" -> district(s, a);
            case "npc" -> {
                if (!admin) return noPerm(s);
                npc(s, a);
            }
            case "reload" -> {
                if (!admin) return noPerm(s);
                plugin.reload();
                t().send(s, "cmd-reloaded");
            }
            default -> help(s, admin);
        }
        return true;
    }

    private boolean noPerm(CommandSender s) {
        t().send(s, "no-permission");
        return true;
    }

    private void help(CommandSender s, boolean admin) {
        for (String line : plugin.getConfig().getStringList("messages.help")) s.sendMessage(Text.mm(line));
        if (admin) {
            for (String line : plugin.getConfig().getStringList("messages.help-admin")) s.sendMessage(Text.mm(line));
            for (String line : plugin.getConfig().getStringList("messages.help-admin-npc")) s.sendMessage(Text.mm(line));
        }
    }

    private void stats(CommandSender s, String[] a) {
        PlayerStore.Data d;
        if (a.length >= 2) d = plugin.players().byName(a[1]);
        else if (s instanceof Player p) d = plugin.players().get(p.getUniqueId());
        else d = null;
        if (d == null) {
            t().send(s, "cmd-unknown-player");
            return;
        }
        int plants = plugin.plants().countOf(d.uuid);
        for (String line : plugin.getConfig().getStringList("messages.stats")) {
            s.sendMessage(Text.mm(line, "player", Text.esc(d.name), "money", plugin.shop().money(d.taler),
                    "heals", String.valueOf(d.heals), "planted", String.valueOf(d.planted), "harvested", String.valueOf(d.harvested),
                    "sabotaged", String.valueOf(d.sabotagedOthers), "got-sabotaged", String.valueOf(d.gotSabotaged),
                    "bowls", String.valueOf(d.bowlsEaten), "plants", String.valueOf(plants),
                    "found", String.valueOf(d.discovered.size()), "total", String.valueOf(plugin.fruits().all().size())));
        }
    }

    private void dm(Player p, String[] a) {
        PlayerStore.Data d = plugin.players().get(p.getUniqueId());
        if (a.length >= 2) {
            String type = a[1].toLowerCase(Locale.ROOT);
            if (DiscordDm.TYPES.contains(type)) {
                if (!d.dmOff.remove(type)) d.dmOff.add(type);
                plugin.players().markDirty();
            } else if (type.equals("aus")) {
                d.dmOff.addAll(DiscordDm.TYPES);
                plugin.players().markDirty();
            } else if (type.equals("an")) {
                d.dmOff.clear();
                plugin.players().markDirty();
            }
        }
        t().send(p, "dm-header");
        for (String type : DiscordDm.TYPES) {
            t().sendRaw(p, t().raw(d.dmOff.contains(type) ? "dm-line-off" : "dm-line-on"),
                    "type", type, "name", t().raw("dm-type-" + type));
        }
    }

    private void season(CommandSender s) {
        Seasons.Season season = plugin.seasons().current();
        if (season == null) {
            t().send(s, "season-off");
            return;
        }
        List<String> boost = new ArrayList<>(), weak = new ArrayList<>();
        for (String id : season.boost()) {
            Fruits.Def d = plugin.fruits().get(id);
            boost.add(d == null ? id : d.name + "<reset>");
        }
        for (String id : season.weak()) {
            Fruits.Def d = plugin.fruits().get(id);
            weak.add(d == null ? id : d.name + "<reset>");
        }
        t().send(s, "season-info", "season", season.name(), "description", season.description(),
                "boost", boost.isEmpty() ? "-" : String.join("<gray>, ", boost),
                "weak", weak.isEmpty() ? "-" : String.join("<gray>, ", weak),
                "days", String.valueOf(plugin.seasons().daysLeft()));
    }

    private void give(CommandSender s, String[] a) {
        if (a.length < 3) {
            t().sendRaw(s, "<gray>/fw give <spieler> <item> [anzahl]");
            return;
        }
        Player target = Bukkit.getPlayerExact(a[1]);
        if (target == null) {
            t().send(s, "cmd-unknown-player");
            return;
        }
        int amount = a.length >= 4 ? parse(a[3], 1) : 1;
        ItemStack item = plugin.items().create(a[2], amount);
        if (item == null) {
            t().send(s, "cmd-unknown-item", "items", String.join(", ", plugin.items().allIds()));
            return;
        }
        for (ItemStack rest : target.getInventory().addItem(item).values()) target.getWorld().dropItemNaturally(target.getLocation(), rest);
        t().send(s, "cmd-given", "amount", String.valueOf(amount), "item", a[2], "player", target.getName());
    }

    private boolean money(CommandSender s, String[] a) {
        // /fw taler <add|set|remove> <spieler> <betrag>
        if (a.length < 4) {
            t().sendRaw(s, "<gray>/fw taler <add|set|remove> <spieler> <betrag>");
            return true;
        }
        PlayerStore.Data d = data(a[2]);
        if (d == null) {
            t().send(s, "cmd-unknown-player");
            return true;
        }
        long v = parse(a[3], 0);
        switch (a[1].toLowerCase(Locale.ROOT)) {
            case "add" -> d.taler += v;
            case "remove" -> d.taler = Math.max(0, d.taler - v);
            case "set" -> d.taler = Math.max(0, v);
            default -> {
                t().sendRaw(s, "<gray>/fw taler <add|set|remove> <spieler> <betrag>");
                return true;
            }
        }
        plugin.players().markDirty();
        t().send(s, "cmd-money-set", "player", d.name, "money", plugin.shop().money(d.taler));
        return true;
    }

    private void heals(CommandSender s, String[] a) {
        if (a.length < 3) {
            t().sendRaw(s, "<gray>/fw heilungen <spieler> <anzahl>");
            return;
        }
        PlayerStore.Data d = data(a[1]);
        if (d == null) {
            t().send(s, "cmd-unknown-player");
            return;
        }
        d.heals = Math.max(0, parse(a[2], 0));
        plugin.players().markDirty();
        t().send(s, "cmd-heals-set", "player", d.name, "heals", String.valueOf(d.heals));
    }

    @SuppressWarnings("deprecation")
    private PlayerStore.Data data(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return plugin.players().get(online.getUniqueId());
        PlayerStore.Data d = plugin.players().byName(name);
        if (d != null) return d;
        OfflinePlayer off = Bukkit.getOfflinePlayer(name);
        if (!off.hasPlayedBefore()) return null;
        PlayerStore.Data nd = plugin.players().get(off.getUniqueId());
        nd.name = name;
        return nd;
    }

    private void district(CommandSender s, String[] a) {
        String sub = a.length < 2 ? "hier" : a[1].toLowerCase(Locale.ROOT);
        DistrictManager dm = plugin.districts();
        if (sub.equals("hier")) {
            if (s instanceof Player p) {
                int ring = dm.ring(p.getLocation());
                t().send(s, "district-here", "district", dm.display(dm.of(p)),
                        "distance", String.valueOf((int) dm.distanceFromSpawn(p.getLocation())),
                        "zone", t().raw(ring == 1 ? "zone-in" : "zone-out"),
                        "min", String.valueOf(dm.zoneMin()), "max", String.valueOf(dm.zoneMax()));
            }
            return;
        }
        if (!s.hasPermission("fruchtwelt.admin")) {
            noPerm(s);
            return;
        }
        if (sub.equals("setzen") || sub.equals("set")) {
            if (a.length < 4) {
                t().sendRaw(s, "<gray>/fw distrikt setzen <spieler> <A|B|C|auto>");
                return;
            }
            PlayerStore.Data d = data(a[2]);
            if (d == null) {
                t().send(s, "cmd-unknown-player");
                return;
            }
            String v = a[3].toUpperCase(Locale.ROOT);
            d.district = DistrictManager.NAMES.contains(v) ? v : null;
            plugin.players().markDirty();
            t().send(s, "district-set", "player", d.name, "district", d.district == null ? t().raw("district-auto") : dm.display(d.district));
            return;
        }
        if (sub.equals("info")) {
            Player target = a.length >= 3 ? Bukkit.getPlayerExact(a[2]) : null;
            if (target == null) {
                t().send(s, "cmd-unknown-player");
                return;
            }
            t().send(s, "district-of", "player", target.getName(), "district", dm.display(dm.of(target)));
            return;
        }
        help(s, true);
    }

    private void npc(CommandSender s, String[] a) {
        String sub = a.length < 2 ? "" : a[1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "entfernen", "löschen", "loeschen", "remove" -> npcRemove(s, a);
            case "wiederherstellen", "zurück", "zurueck" -> t().send(s, "npc-restored", "count", String.valueOf(plugin.npcs().restore()));
            case "liste" -> {
                t().send(s, "npc-list-head", "count", String.valueOf(plugin.npcs().count()), "removed", String.valueOf(plugin.npcs().removedCount()));
                plugin.npcs().countByType().forEach((type, n) -> t().send(s, "npc-list-line", "type", type, "count", String.valueOf(n)));
            }
            case "krank" -> t().send(s, "npc-all-sick", "count", String.valueOf(plugin.npcs().makeAllSick()));
            case "spawn" -> {
                if (!(s instanceof Player p)) {
                    t().send(s, "cmd-player-only");
                    return;
                }
                String type = a.length >= 3 ? a[2].toLowerCase(Locale.ROOT) : "patient";
                String dealerId = null;
                int nameFrom = 3;
                if (type.equals("dealer")) {
                    if (a.length < 4 || plugin.fruits().get(a[3]) == null) {
                        t().sendRaw(s, "<gray>/fw npc spawn dealer <substanz> [name]");
                        return;
                    }
                    dealerId = a[3].toLowerCase(Locale.ROOT);
                    nameFrom = 4;
                }
                if (!NpcManager.TYPES.contains(type)) {
                    t().sendRaw(s, "<gray>/fw npc spawn <" + String.join("|", NpcManager.TYPES) + "> [name]");
                    return;
                }
                String name = a.length > nameFrom ? String.join(" ", Arrays.copyOfRange(a, nameFrom, a.length)) : plugin.npcs().randomName();
                plugin.npcs().adminSpawn(p, type, dealerId, name);
                t().send(s, "npc-spawned", "type", type, "name", Text.esc(name));
            }
            default -> {
                for (String line : plugin.getConfig().getStringList("messages.npc-usage")) s.sendMessage(Text.mm(line));
            }
        }
    }

    private void npcRemove(CommandSender s, String[] a) {
        String what = a.length < 3 ? "" : a[2].toLowerCase(Locale.ROOT);
        NpcManager npcs = plugin.npcs();
        int count;
        switch (what) {
            case "" -> {
                if (!(s instanceof Player p)) {
                    t().send(s, "cmd-player-only");
                    return;
                }
                t().send(s, npcs.removeLookedAt(p) ? "npc-removed" : "npc-none");
                return;
            }
            case "alle", "all" -> count = npcs.removeEverything();
            case "umkreis", "radius" -> {
                if (!(s instanceof Player p)) {
                    t().send(s, "cmd-player-only");
                    return;
                }
                double r;
                try {
                    r = a.length >= 4 ? Double.parseDouble(a[3]) : 10;
                } catch (NumberFormatException e) {
                    r = 10;
                }
                count = npcs.removeRadius(p.getLocation(), Math.min(200, Math.max(1, r)));
            }
            case "name" -> {
                if (a.length < 4) {
                    t().sendRaw(s, "<gray>/fw npc entfernen name <name>");
                    return;
                }
                count = npcs.removeName(String.join(" ", Arrays.copyOfRange(a, 3, a.length)));
            }
            case "dealer" -> {
                if (a.length < 4) count = npcs.removeType("dealer");
                else count = npcs.removeDealer(a[3]);
            }
            default -> {
                if (!NpcManager.TYPES.contains(what) && !what.equals("dorf") && !what.equals("admin")) {
                    for (String line : plugin.getConfig().getStringList("messages.npc-usage")) s.sendMessage(Text.mm(line));
                    return;
                }
                count = npcs.removeType(what);
            }
        }
        t().send(s, "npc-removed-many", "count", String.valueOf(count));
    }

    private void group(Player p, String[] a) {
        if (!plugin.getConfig().getBoolean("groups.enabled", true)) {
            t().send(p, "group-disabled");
            return;
        }
        PlayerStore.Data d = plugin.players().get(p.getUniqueId());
        String sub = a.length >= 2 ? a[1].toLowerCase(Locale.ROOT) : "liste";
        switch (sub) {
            case "add", "hinzufügen" -> {
                if (a.length < 3) {
                    t().sendRaw(p, "<gray>/fw gruppe add <spieler>");
                    return;
                }
                PlayerStore.Data other = data(a[2]);
                if (other == null || other.uuid.equals(p.getUniqueId())) {
                    t().send(p, "cmd-unknown-player");
                    return;
                }
                int max = plugin.getConfig().getInt("groups.max-members", 5);
                if (d.members.size() >= max) {
                    t().send(p, "group-full", "max", String.valueOf(max));
                    return;
                }
                d.members.add(other.uuid);
                plugin.players().markDirty();
                t().send(p, "group-added", "player", Text.esc(other.name));
                plugin.notifier().tell(other.uuid, "group-added-you", "player", Text.esc(p.getName()));
            }
            case "remove", "entfernen" -> {
                PlayerStore.Data other = a.length >= 3 ? data(a[2]) : null;
                if (other == null || !d.members.remove(other.uuid)) {
                    t().send(p, "cmd-unknown-player");
                    return;
                }
                plugin.players().markDirty();
                t().send(p, "group-removed", "player", Text.esc(other.name));
            }
            default -> {
                List<String> names = new ArrayList<>();
                for (java.util.UUID m : d.members) {
                    PlayerStore.Data md = plugin.players().get(m);
                    names.add(md.name);
                }
                t().send(p, "group-list", "members", names.isEmpty() ? "-" : Text.esc(String.join(", ", names)));
            }
        }
    }

    /** /fw punkte <spieler> <heldenpunkte|diamanten|unrein> <add|remove|set> <anzahl> */
    private void points(CommandSender s, String[] a) {
        if (a.length < 5) {
            t().sendRaw(s, "<gray>/fw punkte <spieler> <heldenpunkte|diamanten|unrein> <add|remove|set> <anzahl>");
            return;
        }
        PlayerStore.Data d = data(a[1]);
        if (d == null) {
            t().send(s, "cmd-unknown-player");
            return;
        }
        String kind = a[2].toLowerCase(Locale.ROOT);
        String op = a[3].toLowerCase(Locale.ROOT);
        int n = Math.max(0, parse(a[4], 0));
        if (kind.startsWith("held") || kind.equals("hp")) {
            switch (op) {
                case "add" -> d.taler += n;
                case "remove" -> d.taler = Math.max(0, d.taler - n);
                default -> d.taler = n;
            }
            plugin.players().markDirty();
            t().send(s, "cmd-money-set", "player", d.name, "money", plugin.shop().money(d.taler));
            return;
        }
        boolean dirty = kind.startsWith("unrein") || kind.equals("schwarzgeld");
        Player target = Bukkit.getPlayer(d.uuid);
        if (target == null) {
            t().send(s, "points-offline");
            return;
        }
        if (op.equals("add")) plugin.economy().pay(target, dirty, n);
        else if (op.equals("remove")) plugin.economy().take(target, dirty, Math.min(n, plugin.economy().count(target, dirty)));
        else {
            int have = plugin.economy().count(target, dirty);
            if (have > n) plugin.economy().take(target, dirty, have - n);
            else plugin.economy().pay(target, dirty, n - have);
        }
        t().send(s, "points-set", "player", d.name, "amount", String.valueOf(plugin.economy().count(target, dirty)),
                "currency", plugin.economy().currencyName(dirty));
    }

    private static int parse(String s, int def) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender s, @NotNull Command cmd, @NotNull String label, String @NotNull [] a) {
        boolean admin = s.hasPermission("fruchtwelt.admin");
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            out.addAll(List.of("hilfe", "dashboard", "einweisung", "buch", "gruppe", "city", "miete", "haus", "taler", "stats", "saison", "distrikt", "dm"));
            if (admin) out.addAll(List.of("give", "heilungen", "punkte", "npc", "shop", "reload"));
        } else if (a.length == 2) {
            switch (a[0].toLowerCase(Locale.ROOT)) {
                case "distrikt" -> out.addAll(admin ? List.of("hier", "setzen", "info") : List.of("hier"));
                case "npc" -> out.addAll(List.of("spawn", "entfernen", "wiederherstellen", "liste", "krank"));
                case "dashboard" -> out.add("admin");
                case "miete" -> out.addAll(List.of("info", "einzahlen", "auszahlen", "kündigen"));
                case "haus" -> out.addAll(admin ? List.of("info", "miete", "rauswerfen", "reset") : List.of("info", "miete", "rauswerfen"));
                case "gruppe" -> out.addAll(List.of("add", "remove", "liste"));
                case "city" -> {
                    if (admin) out.addAll(List.of("punkt", "respawn"));
                }
                case "punkte" -> Bukkit.getOnlinePlayers().forEach(pl -> out.add(pl.getName()));
                case "dm" -> {
                    out.addAll(DiscordDm.TYPES);
                    out.add("an");
                    out.add("aus");
                }
                case "taler" -> {
                    if (admin) out.addAll(List.of("add", "set", "remove"));
                }
                case "give", "heilungen", "stats" -> Bukkit.getOnlinePlayers().forEach(pl -> out.add(pl.getName()));
                default -> {
                }
            }
        } else if (a.length == 3) {
            switch (a[0].toLowerCase(Locale.ROOT)) {
                case "give" -> out.addAll(plugin.items().allIds());
                case "npc" -> {
                    if (a[1].equalsIgnoreCase("spawn")) out.addAll(NpcManager.TYPES);
                    if (a[1].equalsIgnoreCase("entfernen")) {
                        out.addAll(List.of("alle", "umkreis", "name", "dorf", "admin"));
                        out.addAll(NpcManager.TYPES);
                    }
                }
                case "taler" -> Bukkit.getOnlinePlayers().forEach(pl -> out.add(pl.getName()));
                case "gruppe" -> Bukkit.getOnlinePlayers().forEach(pl -> out.add(pl.getName()));
                case "punkte" -> out.addAll(List.of("heldenpunkte", "diamanten", "unrein"));
                case "distrikt" -> Bukkit.getOnlinePlayers().forEach(pl -> out.add(pl.getName()));
                default -> {
                }
            }
        } else if (a.length == 4 && a[0].equalsIgnoreCase("punkte")) {
            out.addAll(List.of("add", "remove", "set"));
        } else if (a.length == 4 && a[0].equalsIgnoreCase("npc") && a[2].equalsIgnoreCase("dealer")) {
            plugin.fruits().all().forEach(d -> out.add(d.id));
        } else if (a.length == 4 && a[0].equalsIgnoreCase("distrikt") && a[1].equalsIgnoreCase("setzen")) {
            out.addAll(DistrictManager.NAMES);
            out.add("auto");
        }
        String last = a[a.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
