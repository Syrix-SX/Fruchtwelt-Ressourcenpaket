package dev.fruchtwelt;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HexFormat;

/**
 * Fruchtwelt by Syrix – Distrikte A/B/C, Früchte, Bäume, Sabotage, Fruchtbowls, NPC-Heilung und Shop.
 */
public final class FruchtweltPlugin extends JavaPlugin implements Listener {

    private Text text;
    private Fruits fruits;
    private CustomItems items;
    private DistrictManager districts;
    private PlayerStore players;
    private PlantManager plants;
    private Notifier notifier;
    private Seasons seasons;
    private RecipeManager recipes;
    private ShopManager shop;
    private NpcManager npcs;
    private BookGui book;
    private Tents tents;
    private Sabotage sabotage;
    private DiscordDm dm;
    private Economy economy;
    private Dialogue dialogue;
    private DealerManager dealers;
    private BoostManager boosts;
    private EnchantCaps enchantCaps;
    private Dashboard dashboard;
    private HouseManager houses;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        updateConfig();
        text = new Text(this);
        fruits = new Fruits(this);
        items = new CustomItems(this);
        districts = new DistrictManager(this);
        players = new PlayerStore(this);
        plants = new PlantManager(this);
        notifier = new Notifier(this);
        seasons = new Seasons(this);
        recipes = new RecipeManager(this);
        shop = new ShopManager(this);
        npcs = new NpcManager(this);
        book = new BookGui(this);
        tents = new Tents(this);
        sabotage = new Sabotage(this);
        dm = new DiscordDm(this);
        economy = new Economy(this);
        dialogue = new Dialogue(this);
        dealers = new DealerManager(this);
        boosts = new BoostManager(this);
        enchantCaps = new EnchantCaps(this);
        dashboard = new Dashboard(this);
        houses = new HouseManager(this);

        loadConfigParts();
        players.load();
        plants.load();
        houses.load();
        plants.start();

        var pm = getServer().getPluginManager();
        pm.registerEvents(this, this);
        pm.registerEvents(notifier, this);
        pm.registerEvents(new DistrictListener(this), this);
        pm.registerEvents(new PlantListener(this), this);
        pm.registerEvents(new ConsumeListener(this), this);
        pm.registerEvents(recipes, this);
        pm.registerEvents(npcs, this);
        pm.registerEvents(economy, this);
        pm.registerEvents(houses, this);
        Bukkit.getScheduler().runTaskTimer(this, () -> districts.syncTick(), 200L, 20L * 30);
        pm.registerEvents(enchantCaps, this);
        ToolListener tools = new ToolListener(this);
        pm.registerEvents(tools, this);
        Bukkit.getScheduler().runTaskTimer(this, tools::heldEffectsTick, 40L, 40L);
        pm.registerEvents(new Gui.Listen(), this);

        FwCommand cmd = new FwCommand(this);
        PluginCommand pc = getCommand("fw");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }

        long saveTicks = Math.max(1, getConfig().getLong("general.save-minutes", 5)) * 60 * 20;
        Bukkit.getScheduler().runTaskTimer(this, this::saveAll, saveTicks, saveTicks);

        if (Bukkit.getPluginManager().getPlugin("CraftLink") != null) {
            getLogger().info("CraftLink gefunden – Sabotage-, Ernte- und Heil-Events stehen für den Discord-Bot bereit.");
        }
        getLogger().info("Fruchtwelt by Syrix ist bereit (" + fruits.all().size() + " Früchte).");
    }

    @Override
    public void onDisable() {
        if (plants != null) plants.stop();
        if (npcs != null) {
            npcs.stop();
            npcs.removeAll();
        }
        saveAll();
    }

    private void loadConfigParts() {
        text.reload();
        districts.load();
        tents.load();
        fruits.load();
        items.load();
        recipes.reload();
        seasons.load();
        sabotage.load();
        dm.reload();
        dialogue.load();
        boosts.load();
        dealers.load();
        enchantCaps.start();
        shop.load();
        npcs.load();
    }

    /** Fehlende Einstellungen aus der neuen Version automatisch in die vorhandene config.yml eintragen. */
    private void updateConfig() {
        getConfig().options().copyDefaults(true);
        // 3.2.1: Prestige-Spitzhacke aus Gold konnte keine Erze abbauen -> auf Netherit umstellen
        if ("GOLDEN_PICKAXE".equalsIgnoreCase(getConfig().getString("items.prestige_spitzhacke.material", ""))) {
            getConfig().set("items.prestige_spitzhacke.material", "NETHERITE_PICKAXE");
        }
        saveConfig();
        // Neu einlesen, damit die gerade ergänzten Einträge auch sofort im Speicher stehen
        super.reloadConfig();
    }

    public void reload() {
        reloadConfig();
        updateConfig();
        loadConfigParts();
        plants.start();
        for (Player p : Bukkit.getOnlinePlayers()) items.refreshInventory(p);
    }

    public void saveAll() {
        if (plants != null) plants.save();
        if (players != null) players.save();
        if (houses != null) houses.save();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (getConfig().getBoolean("resourcepack.enabled", false)) {
            String url = getConfig().getString("resourcepack.url", "");
            String sha1 = getConfig().getString("resourcepack.sha1", "");
            if (url != null && !url.isBlank()) {
                byte[] hash = null;
                try {
                    if (sha1 != null && sha1.length() == 40) hash = HexFormat.of().parseHex(sha1);
                } catch (IllegalArgumentException ignored) {
                }
                p.setResourcePack(url, hash, Text.mm(getConfig().getString("resourcepack.prompt", "")),
                        getConfig().getBoolean("resourcepack.required", false));
            }
        }
        if (getConfig().getBoolean("tutorial.hint-on-join", true) && !players.get(p.getUniqueId()).tutorialSeen) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (p.isOnline()) text.send(p, "tutorial-hint");
            }, 140L);
        }
        if (getConfig().getBoolean("seasons.announce-on-join", true)) {
            Seasons.Season s = seasons.current();
            if (s != null) {
                Bukkit.getScheduler().runTaskLater(this, () -> {
                    if (p.isOnline()) text.send(p, "season-join", "season", s.name(), "days", String.valueOf(seasons.daysLeft()));
                }, 100L);
            }
        }
    }

    public Text text() { return text; }
    public Fruits fruits() { return fruits; }
    public CustomItems items() { return items; }
    public DistrictManager districts() { return districts; }
    public PlayerStore players() { return players; }
    public PlantManager plants() { return plants; }
    public Notifier notifier() { return notifier; }
    public Seasons seasons() { return seasons; }
    public RecipeManager recipes() { return recipes; }
    public ShopManager shop() { return shop; }
    public NpcManager npcs() { return npcs; }
    public BookGui book() { return book; }
    public Tents tents() { return tents; }
    public Sabotage sabotage() { return sabotage; }
    public DiscordDm dm() { return dm; }
    public Economy economy() { return economy; }
    public Dialogue dialogue() { return dialogue; }
    public DealerManager dealers() { return dealers; }
    public BoostManager boosts() { return boosts; }
    public EnchantCaps enchantCaps() { return enchantCaps; }
    public Dashboard dashboard() { return dashboard; }
    public HouseManager houses() { return houses; }
}
