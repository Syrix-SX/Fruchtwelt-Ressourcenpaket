package dev.fruchtwelt;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Eigene Items. Jedes Item bekommt eine unsichtbare Markierung (fw:id), so bleiben normale
 * Minecraft-Items wie das Diamantschwert unverändert. Das Aussehen kommt über item_model aus dem Ressourcenpaket.
 */
public final class CustomItems {

    public static final String BOWL = "fruchtbowl";
    public static final String MASTER_BOOK = "meisterbuch";
    /** Verzauberungen, für die das Ressourcenpaket ein eigenes Buch-Bild hat. */
    private static final java.util.Set<String> PACK_BOOKS = java.util.Set.of("efficiency", "unbreaking", "sharpness", "protection",
            "fortune", "looting", "power", "feather_falling", "fire_aspect", "respiration", "mending", "silk_touch", "fire_protection");
    public static final String SABOTAGE = "anti_duenger";

    public static boolean isSabotagePack(String id) {
        return SABOTAGE.equals(id);
    }

    public static final class Other {
        public String id;
        public Material material;
        public String name;
        public List<String> lore = new ArrayList<>();
        public List<String> recipe = new ArrayList<>();
        public List<String> enchants = new ArrayList<>();
        public int maxStack;
        public boolean unbreakable;
        public String model;
        /** Fähigkeiten, z. B. "lifesteal:15", "hammer", "poison:2:4" -> Name -> Zahlen */
        public Map<String, double[]> abilities = new LinkedHashMap<>();
        public List<Effects.Spec> heldEffects = new ArrayList<>();
    }

    /** Fähigkeiten des Items in der Hand (leer, wenn keins). */
    public Map<String, double[]> abilities(ItemStack it) {
        Other o = others.get(idOf(it));
        return o == null ? Map.of() : o.abilities;
    }

    public List<Effects.Spec> heldEffects(ItemStack it) {
        Other o = others.get(idOf(it));
        return o == null ? List.of() : o.heldEffects;
    }

    private final FruchtweltPlugin plugin;
    public final NamespacedKey keyId;
    public final NamespacedKey keyBowl;
    public final NamespacedKey keyStolen;
    public final NamespacedKey keyBoost;
    public final NamespacedKey keyVein;
    private final Map<String, Other> others = new LinkedHashMap<>();
    private boolean glint = true;

    public CustomItems(FruchtweltPlugin plugin) {
        this.plugin = plugin;
        this.keyId = new NamespacedKey(plugin, "id");
        this.keyBowl = new NamespacedKey(plugin, "bowl");
        this.keyStolen = new NamespacedKey(plugin, "stolen");
        this.keyBoost = new NamespacedKey(plugin, "boost");
        this.keyVein = new NamespacedKey(plugin, "veinminer");
    }

    public void load() {
        others.clear();
        glint = plugin.getConfig().getBoolean("general.item-glint", true);
        ConfigurationSection root = plugin.getConfig().getConfigurationSection("items");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection c = root.getConfigurationSection(id);
            if (c == null) continue;
            Other o = new Other();
            o.id = id.toLowerCase(Locale.ROOT);
            o.material = Material.matchMaterial(c.getString("material", "PAPER"));
            if (o.material == null) {
                plugin.getLogger().warning("items." + id + ".material ist unbekannt, nutze PAPER");
                o.material = Material.PAPER;
            }
            o.name = c.getString("name", id);
            o.lore = c.getStringList("lore");
            o.recipe = c.getStringList("recipe");
            o.enchants = c.getStringList("enchantments");
            o.maxStack = c.getInt("max-stack", 0);
            o.unbreakable = c.getBoolean("unbreakable", false);
            o.model = c.getString("model");
            for (String a : c.getStringList("abilities")) {
                String[] parts = a.trim().toLowerCase(Locale.ROOT).split(":");
                double[] vals = new double[parts.length - 1];
                for (int i = 1; i < parts.length; i++) {
                    try {
                        vals[i - 1] = Double.parseDouble(parts[i]);
                    } catch (NumberFormatException ex) {
                        plugin.getLogger().warning("items." + id + ".abilities: " + a + " ist ungültig");
                    }
                }
                o.abilities.put(parts[0], vals);
            }
            o.heldEffects = Effects.parse(c.getStringList("held-effects"), plugin.getLogger());
            others.put(o.id, o);
        }
    }

    public Other other(String id) {
        return others.get(id);
    }

    public Set<String> allIds() {
        Set<String> ids = new LinkedHashSet<>();
        for (Fruits.Def d : plugin.fruits().all()) {
            ids.add(d.id);
            if (d.plantable) ids.add(d.seedId());
        }
        ids.addAll(others.keySet());
        return ids;
    }

    public String idOf(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(keyId, PersistentDataType.STRING);
    }

    public boolean is(ItemStack item, String id) {
        return id.equals(idOf(item));
    }

    public ItemStack create(String id, int amount) {
        if (id == null) return null;
        id = id.toLowerCase(Locale.ROOT);
        ItemStack item;
        Fruits.Def fruit = plugin.fruits().get(id);
        Fruits.Def seed = plugin.fruits().bySeed(id);
        Other other = others.get(id);
        if (fruit != null) item = new ItemStack(fruit.item);
        else if (seed != null) item = new ItemStack(seed.seedItem);
        else if (other != null) item = new ItemStack(other.material);
        else if (id.equals(BOWL)) item = new ItemStack(Material.MUSHROOM_STEW);
        else return null;
        ItemMeta meta = item.getItemMeta();
        meta.getPersistentDataContainer().set(keyId, PersistentDataType.STRING, id);
        item.setItemMeta(meta);
        if (other != null) {
            ItemMeta m = item.getItemMeta();
            for (String e : other.enchants) {
                String[] p = e.toLowerCase(Locale.ROOT).split(":");
                Enchantment ench = Registry.ENCHANTMENT.get(NamespacedKey.minecraft(p[0]));
                if (ench == null) {
                    plugin.getLogger().warning("items." + id + ": unbekannte Verzauberung " + e);
                    continue;
                }
                int lvl = p.length > 1 ? parseInt(p[1], 1) : 1;
                m.addEnchant(ench, lvl, true);
            }
            if (other.unbreakable) m.setUnbreakable(true);
            item.setItemMeta(m);
        }
        refresh(item);
        item.setAmount(Math.max(1, amount));
        return item;
    }

    /** Name, Lore und Aussehen auf den aktuellen Config-Stand bringen (Verzauberungen bleiben). */
    public void refresh(ItemStack item) {
        String id = idOf(item);
        if (id == null || id.equals(MASTER_BOOK)) return;
        ItemMeta meta = item.getItemMeta();
        Text t = plugin.text();
        Fruits.Def fruit = plugin.fruits().get(id);
        Fruits.Def seed = plugin.fruits().bySeed(id);
        Other other = others.get(id);
        if (fruit == null && seed == null && other == null && !id.equals(BOWL)) return; // aus der Config entfernt
        List<String> lore = new ArrayList<>();
        if (fruit != null) {
            meta.displayName(Text.item(fruit.name));
            lore.addAll(fruit.lore);
            lore.add(Text.fill(t.raw("lore-effect"), "effects", fruit.effectText()));
            lore.add(Text.fill(t.raw("lore-use")));
            lore.add(Text.fill(t.raw(fruit.legal() ? "lore-legal" : "lore-illegal"), "tier", fruit.tier));
        } else if (seed != null) {
            meta.displayName(Text.item(seed.seedName));
            lore.addAll(seed.seedLore);
            lore.add(Text.fill(t.raw("lore-seed-" + seed.kind.name().toLowerCase(Locale.ROOT)), "time", Text.duration(seed.growSeconds)));
            lore.add(Text.fill(t.raw("lore-rules"), "rules", plugin.districts().rulesText(seed.rules)));
        } else if (other != null) {
            meta.displayName(Text.item(other.name));
            lore.addAll(other.lore);
            if (other.maxStack > 0) meta.setMaxStackSize(Math.min(99, other.maxStack));
        } else if (id.equals(BOWL)) {
            List<String> fruits = bowlFruits(item);
            meta.displayName(Text.item(plugin.getConfig().getString("bowls.name", "<gold>Fruchtbowl")));
            for (String f : fruits) {
                Fruits.Def d = plugin.fruits().get(f);
                lore.add(Text.fill(t.raw("lore-bowl-line"), "fruit", d == null ? f : d.name));
            }
            int pct = (int) Math.round(plugin.recipes().failChance(fruits.size()) * 100);
            lore.add(Text.fill(t.raw("lore-bowl-fail"), "chance", String.valueOf(pct)));
            meta.setMaxStackSize(1);
        }
        String boost = meta.getPersistentDataContainer().get(keyBoost, PersistentDataType.STRING);
        if (boost != null) {
            BoostManager.Booster b = plugin.boosts().get(boost);
            meta.displayName(Text.item(Text.fill(t.raw("boost-name"), "item", fruit != null ? fruit.name : id)));
            lore.add(Text.fill(t.raw("boost-lore"), "boost", b == null ? boost : b.name()));
        }
        if (meta.getPersistentDataContainer().has(keyStolen, PersistentDataType.BYTE)) lore.add(t.raw("lore-stolen"));
        meta.lore(Text.itemLines(lore));
        String model = fruit != null ? fruit.model : seed != null ? seed.seedModel : other != null ? other.model
                : id.equals(BOWL) ? plugin.getConfig().getString("bowls.model") : null;
        if (packModels() && model != null && !model.isBlank()) {
            NamespacedKey key = NamespacedKey.fromString(model);
            if (key != null) meta.setItemModel(key);
        }
        if (glint && other == null && !id.equals(BOWL)) meta.setEnchantmentGlintOverride(true);
        meta.addItemFlags(ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        item.setItemMeta(meta);
    }

    /** Eigene Modelle nur nutzen, wenn das Ressourcenpaket wirklich verschickt wird (sonst lila-schwarze Kästchen). */
    public boolean packModels() {
        String url = plugin.getConfig().getString("resourcepack.url", "");
        return plugin.getConfig().getBoolean("resourcepack.enabled", false) && url != null && !url.isBlank()
                && plugin.getConfig().getBoolean("resourcepack.item-models", true);
    }

    /** Alle eigenen Items im Inventar eines Spielers auf den aktuellen Stand bringen. */
    public void refreshInventory(org.bukkit.entity.Player p) {
        var inv = p.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack it = inv.getItem(i);
            if (idOf(it) == null) continue;
            ItemStack copy = it.clone();
            Other o = others.get(idOf(it));
            if (o != null && o.material != null && o.material != copy.getType()) copy = copy.withType(o.material);
            refresh(copy);
            inv.setItem(i, copy);
        }
    }

    public ItemStack bowl(List<String> fruitIds) {
        ItemStack item = new ItemStack(Material.MUSHROOM_STEW);
        ItemMeta meta = item.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(keyId, PersistentDataType.STRING, BOWL);
        pdc.set(keyBowl, PersistentDataType.STRING, String.join(",", fruitIds));
        item.setItemMeta(meta);
        refresh(item);
        return item;
    }

    public List<String> bowlFruits(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return List.of();
        String s = item.getItemMeta().getPersistentDataContainer().get(keyBowl, PersistentDataType.STRING);
        if (s == null || s.isEmpty()) return List.of();
        return new ArrayList<>(Arrays.asList(s.split(",")));
    }

    /** Verzauberungsbuch über dem normalen Maximum (z. B. Effizienz 10). */
    public ItemStack masterBook(Enchantment ench, int level) {
        ItemStack item = new ItemStack(Material.ENCHANTED_BOOK);
        EnchantmentStorageMeta meta = (EnchantmentStorageMeta) item.getItemMeta();
        if (plugin.getConfig().getBoolean("enchant-caps.enabled", true)) level = Math.min(level, plugin.enchantCaps().cap(ench));
        meta.addStoredEnchant(ench, level, true);
        meta.getPersistentDataContainer().set(keyId, PersistentDataType.STRING, MASTER_BOOK);
        meta.displayName(Text.item(Text.fill(plugin.text().raw("master-book-name"),
                "enchant", enchantName(ench), "level", Effects.roman(level))));
        meta.lore(Text.itemLines(List.of(plugin.text().raw("master-book-lore"))));
        if (packModels()) {
            String key = ench.getKey().getKey();
            meta.setItemModel(NamespacedKey.fromString(PACK_BOOKS.contains(key) ? "fruchtwelt:meisterbuch_" + key : "fruchtwelt:meisterbuch"));
        }
        item.setItemMeta(meta);
        return item;
    }

    public String enchantName(Enchantment e) {
        String key = e.getKey().getKey();
        String name = plugin.getConfig().getString("enchant-names." + key);
        return name != null ? name : key;
    }

    private static int parseInt(String s, int def) {
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
