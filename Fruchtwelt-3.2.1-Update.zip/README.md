# Fruchtwelt 3.2 by Syrix – Anbau-Plugin

# Neu in Version 3.2

## Distrikte automatisch über Häuser & Miete
- Admin setzt Haus-Schilder: Zeile 1 `[Haus]`, Zeile 2 `A`/`B`/`C`, Zeile 3 Kaufpreis in Diamanten.
- Spieler kaufen Häuser per Rechtsklick und vermieten sie: Schild anschauen, `/fw haus miete <preis>`.
- Mieter klicken auf das Schild und ziehen ein. Wer mietet oder sein eigenes Haus bewohnt, ist automatisch in
  dessen Distrikt. Ohne Wohnung: Distrikt C.
- Die Miete geht **an den Vermieter**: Mieter zahlen mit `/fw miete einzahlen <anzahl>` aufs Mietkonto, jede Woche
  wird automatisch abgebucht. Vermieter holen ihr Geld mit `/fw miete auszahlen`. Wer nicht zahlt: Warnung,
  2 Tage Schonfrist, dann Rauswurf (zurück nach C).
- Das Plugin setzt die **LuckPerms-Gruppe** (`district_a/b/c`) automatisch. CraftLink macht daraus die
  Discord-Rolle. Ausnahmen: `/fw distrikt setzen <spieler> <A|B|C|auto>`.

## Neue Waffen & Werkzeuge (mit Fähigkeiten aus der Config)
Smaragdklinge (Gift), Frostklinge (Langsamkeit), Donnerklinge (Blitz), Blutklinge (Lebensraub + Ausdörren),
Jägerbogen (Feuer + Krit), Erntesense (erntet im Umkreis, pflanzt Felder neu), Goldene Gießkanne (gießt im Umkreis).
**Prestige-Stufe** im Shop (ab 250 Heilungen): goldener Prestige-Säbel, -Spitzhacke (Autosmelt + Magnet),
-Axt und -Schaufel – unzerstörbar, mit Effekten in der Hand.
Eigene Items baust du in der Config mit `abilities` (Liste steht dort).

## Logischer
- Die Config wird bei jedem Start **automatisch ergänzt** – nie mehr alte Config löschen.
- Klick auf Gras pflanzt einfach darunter.
- Fehlermeldungen sagen genau, was fehlt (z. B. „3/10 Zelt-Blöcke“ oder welcher Boden gebraucht wird).

# Neu in Version 3

## City (Drug_City)
- Alle NPCs sehen aus wie Spieler (Minecraft-„Mannequins“, kein Extra-Plugin nötig) und bekommen nach jedem
  Neustart zufällige Skins aus `npcs.skins`.
- In der City stehen bzw. laufen: Patienten, Heiler-Shop, ein allgemeiner Händler, **pro Substanz ein eigener
  Händler**, der Juwelier (Polierer), der Scam-Händler und nachts der Schwarzmarkt.
- `city.mode: random` = Händler stehen zufällig in der City, `points` = nur an festen Punkten
  (ingame mit `/fw city punkt` setzen). `city.wander` = frei herumlaufen an/aus.
- Hinkommen: EssentialsX `/setwarp city` einmal in der City setzen → Spieler nutzen `/warp city`.
  Alternativ `/fw city`.

## Geld
- **Diamanten** (echte Diamant-Items) – legale Händler zahlen damit. Passt zu jedem Diamanten-Economy-Plugin.
- **Unreine Diamanten** (Schwarzgeld) – illegale Händler und der Schwarzmarkt zahlen damit, außerdem kann ein
  Diamant aus Erz unrein sein (`dirty-diamonds.ore`). Der **Juwelier** macht daraus echte Diamanten,
  der Abzug hängt von der echten Uhrzeit ab (`dirty-diamonds.polisher.fees`).
- **Heldenpunkte** – fürs Heilen, für den Heiler-Shop.
- Admin: `/fw punkte <spieler> <heldenpunkte|diamanten|unrein> <add|remove|set> <anzahl>`

## Händler
- Jeder Substanz-Händler zahlt für „seine“ Ware am meisten und hat 2 Nebenangebote. Beim Neustart wird neu
  gewürfelt, und die Preise schwanken jeden Tag. Grundpreise: `sell` bei jeder Substanz.
- Jeder Händler hat einen **Tagesauftrag** mit Bonus.
- Illegale Händler (unreine Diamanten) reden nur mit Distrikt C.
- **Scam-Händler** (nur A/B): kauft gestohlene Ware teurer. Gestohlen ist, was A/B einem C-Spieler beim Töten
  abnimmt. Wer dort verkauft, leuchtet 10 Minuten und C wird informiert.

## Patienten
- Kranke husten, niesen, laufen langsamer und reden – über 7 Persönlichkeiten mit vielen Sätzen
  (`dialog.yml`, beliebig erweiterbar). Sie reagieren auf deinen Namen, Tageszeit, Wetter und darauf,
  wie vielen du schon geholfen hast.
- Kranke Patienten tauchen auch in **normalen Dörfern** auf (Farmwelt usw.), `villages:` in der Config.

## Aufpuschen
Substanz + Zucker / Leuchtstaub / Redstone / Lohenstaub craften = verstärkte Substanz (stärker oder länger).
Beim Benutzen kann es schiefgehen (Vergiftung, Übelkeit …). Alles in `boost:`.

## Bücher und Verzauberungen
- **Veinminer-Buch** im Shop: am Amboss auf Spitzhacke/Axt/Schaufel → ganze Erzadern auf einmal.
- Mehr Shop-Angebote (Reparatur, Behutsamkeit, Federfall, Schutz, Stärke, Packs …).
- `enchant-caps`: Keine Verzauberung kann über die Grenze kommen – auch nicht per `/enchant` oder Amboss.

## Menüs, Einweisung, Gruppen
- `/fw dashboard` – Spieler-Menü, `/fw dashboard admin` – Einstellungen per Klick (an/aus, Zahlen, NPCs neu würfeln).
- `/fw einweisung` – Einweisung in 6 Seiten (Texte in `tutorial.pages`).
- `/fw gruppe add <name>` – Freunde dürfen deine Pflanzen ernten/pflegen (`groups.enabled`).

## Distrikte über CraftLink
Fruchtwelt bietet die Schnittstelle `dev.fruchtwelt.api.DistrictProvider` an. Sobald CraftLink im nächsten Update
den Distrikt liefert (z. B. aus Discord-Rollen oder der Miete), nutzt Fruchtwelt das automatisch
(`districts.sources`). Bis dahin läuft alles wie bisher über LuckPerms-Gruppen.

Die `dialog.yml` wird automatisch angelegt.


Plugin für Paper 26.3 (Java 25). Läuft komplett automatisch: keine Bereiche, kein Ressourcenpaket nötig.

## 1. Bauen und installieren (wie bei CraftLink)

1. Im GitHub-Repo `Fruchtwelt` die alten Ordner `src` und `resourcepack` sowie die alte Paket-ZIP löschen
   und den Inhalt dieser ZIP hochladen (`src`, `build.gradle.kts`, `settings.gradle.kts`, `README.md`, `.github`).
2. **Actions** → grüner Haken abwarten → Artifact **Fruchtwelt** herunterladen → `.jar` in den `plugins`-Ordner.
3. **Wichtig:** Die alte `plugins/Fruchtwelt/config.yml` löschen (oder umbenennen), bevor du neu startest.
   Sonst bleibt die alte Config mit den alten Früchten drin.
4. Server neu starten.

Kommt ein rotes Kreuz, schick mir den Fehlertext.

## 1b. Ressourcenpaket (eigene Texturen)

Die Früchte aus Version 1, Samen, Werkzeuge, Heilmittel, Sabotagepaket, Gießkanne, Anbau-Buch und Bowl haben
eigene Texturen. Die Substanzen aus eurem Konzept sehen weiter wie normale Minecraft-Items aus.

1. `Fruchtwelt-Ressourcenpaket.zip` liegt im Repo. Draufklicken → **Raw** bzw. "View raw" → Adresse kopieren.
2. In der `config.yml` bei `resourcepack.url` eintragen, z. B.
   `https://github.com/Syrix-SX/Fruchtwelt-Plugin-2.2.0/raw/main/Fruchtwelt-Ressourcenpaket.zip`
3. `sha1` ist schon eingetragen: `b63ef30e82cf488a54f5789be290cc552b75ffde` (passt nur zu genau dieser ZIP).
4. `/fw reload`, neu einloggen, Paket annehmen.

**Wichtig:** Das Repo muss **öffentlich** sein, sonst kann Minecraft das Paket nicht herunterladen.
Ist dein Repo privat, lade nur die ZIP in ein zweites, öffentliches Repo hoch.
Ohne Link sehen alle Items einfach wie normale Minecraft-Items aus (Apfel, Papier ...), es geht nichts kaputt.

## 2. Distrikte (A reich, B Mitte, C arm)

Der Distrikt gehört zum **Spieler**. Das Plugin erkennt ihn automatisch:

- Hat der Spieler eine LuckPerms-Gruppe wie `district_a` / `distrikt_a` (B, C entsprechend), passt alles schon.
  Heißen eure Gruppen anders, trag sie in der Config bei `districts.A.permissions` ein, z. B. `group.reich`.
- Alternativ das Recht `fruchtwelt.distrikt.a` / `.b` / `.c` an die Gruppe geben.
- Von Hand: `/fw distrikt setzen <spieler> <A|B|C|auto>`.
- Wer nichts hat, ist in **C** (`districts.default`).

`/fw distrikt` zeigt jedem seinen Distrikt und wie weit er vom Spawn weg ist.

## 3. Regeln (alles in der Config änderbar)

| | Wer | Wo | Zelt |
|---|---|---|---|
| Kräuter, Fliegenpilze anbauen (alles für Schmerzmittel) | alle | überall | **weißes Zelt** daneben |
| Heilkräuter herstellen | alle | überall | – |
| Schmerzmittel herstellen | nur A | Anbauzone | Werkbank im **grünen Zelt** |
| Vogel-Beeren, Mais, Tree-Berrys, Zauberbirne anbauen | nur C | Anbauzone | **weißes Zelt** daneben |
| Lotusblume, Dragon-Fruit herstellen | nur C | überall | – |

**Anbauzone:** 800 bis 1400 Blöcke vom Spawn. Beim Überqueren der Grenzen bekommt jeder die passende Chat-Meldung
(C: "Ab hier kannst du anbauen", A: "Ab hier kannst du Schmerzmittel herstellen", B: keine Meldung).

**Zelt:** mindestens 10 Blöcke weiße Wolle, Teppich oder Banner im Umkreis von 4 Blöcken um die Pflanze
(grün bzw. hellgrün für das Labor um die Werkbank). Fehlt das Zelt später, hört die Pflanze auf zu wachsen.

## 4. Substanzen

| Stufe | Name | Aussehen | Bekommt man … |
|---|---|---|---|
| Legal | Schmerzmittel | Eisennugget | Herstellung (9 Stück) |
| Einfach | Kräuter | Busch | Samen: 25 % beim Ernten reifer Karotten |
| Einfach | Fliegenpilz | Roter Pilz | Sporen: 35 % beim Abbauen roter Pilze |
| Mittel | Heilkräuter | Fackellilie | Herstellung (2 Stück) |
| Einfach | Vogel-Beeren | Süßbeeren | Samen: 30 % beim Pflücken von Süßbeeren |
| Einfach | Mais | Goldener Löwenzahn | Samen: 20 % beim Ernten von reifem Weizen |
| Mittel | Tree-Berrys | Rosa Blütenblätter | Setzling: 15 % aus Pappel-/Azaleen-Laub |
| Mittel | Zauberbirne | Leuchtbeeren | Setzling: 10 % aus Kirschlaub |
| Schwer | Lotusblume | Kaktusblüte | Herstellung (1 Stück) |
| Schwer | Dragon-Fruit | Sporenblüte | Herstellung (2 Stück) |

- Benutzen: **Rechtsklick** mit dem Item. Jede Substanz hat eine Wartezeit (`use-cooldown-seconds`).
- Tree-Berrys: Der Baum bekommt blühende Azaleen-Blätter. **Diese abbauen** = Beeren ernten.
- Eigene Items glitzern, damit man sie von normalen unterscheiden kann. Normale Items bleiben normal.

**Früchte aus Version 1** sind auch wieder dabei (mit eigenen Texturen, ohne Zelt):

| Stufe | Früchte | Wer darf anbauen |
|---|---|---|
| A | Sonnenbeere, Honigapfel (Baum), Minzblatt | alle |
| B | Sturmfrucht, Eisenapfel (Baum), Nachtbeere | B und C |
| C | Blutapfel (Baum), Phönixfrucht, Schattenbeere | nur C |

Samen findet man wie früher in Gras und Laub oder craftet sie (Rezepte im Anbau-Buch).
Kranke NPCs brauchen jetzt auch wieder diese Früchte (Schnupfen, Grippe, Schattenfluch).

**Rezepte** (nach euren Bildern; die Anordnung im Crafting-Feld ist egal, nur die Zutaten zählen):

| Ergebnis | Zutaten |
|---|---|
| 9 Schmerzmittel | Eisenbarren + 2 Kräuter + 2 Heilkräuter |
| 2 Heilkräuter | 4 Kräuter + Fliegenpilz |
| 1 Lotusblume | 2 Tree-Berrys + 2 Heilkräuter + Zauberbirne |
| 2 Dragon-Fruit | Tree-Berrys + Schmerzmittel + Fliegenpilz + Kräuter + Heilkräuter |
| 9 Dünger | 4 Knochenmehl + Ei |
| 8 Anti-Dünger | 4 Harzklumpen + Knochenmehl |

## 5. Dünger und Anti-Dünger

- **Dünger** (grüner Farbstoff): wirkt wie Knochenmehl, auf Anbau-Pflanzen überspringt er 25 % der Wachstumszeit.
- **Anti-Dünger** (Harzziegel): Rechtsklick auf eine fremde Pflanze → du siehst sofort, **wer sie angebaut hat**.
  Die Pflanze welkt, über ihr steht "Anti-Dünger von <Name>", und der Besitzer bekommt eine Nachricht
  (auch wenn er offline war). Er hat 60 Minuten Spielzeit, sie mit **Dünger** zu retten, sonst geht sie ein.
  `anti-duenger.rescue-minutes: 0` = Pflanze ist sofort kaputt.

## Sabotagepaket

Rechtsklick mit dem Sabotagepaket auf eine fremde Pflanze (nur in der Anbauzone, alle 10 Minuten).
Dann passiert zufällig eins davon:

| Folge | Was passiert | Gegenmittel |
|---|---|---|
| Fäulnis | Pflanze stirbt in 60 Minuten | Pflanzenmedizin |
| Vergiftete Erde | Pflanze stirbt in 60 Minuten | Bodenkur |
| Wachstumsbremse | 2 Stunden nur halb so schnell | Dünger |
| Verdorrt | Wachstum zurück auf 0 % | – |
| Schädlinge | nächste Ernte nur die Hälfte | Schädlingsspray |
| Vertauscht | nächste Ernte gibt nur Unkraut | Pflanzenmedizin |
| Bienenalarm | beim Ernten greifen Bienen an | – |
| Stinkbombe | grüne Wolke, wer erntet, dem wird übel | – |
| Konfetti | Feuerwerk und Konfetti, sonst nichts | – |
| Fehlschlag | Paket explodiert beim Saboteur selbst | – |

Über der Pflanze steht danach "Sabotiert von <Name>", und der Besitzer bekommt eine Nachricht (im Spiel und per DM).
Wie oft jede Folge kommt, steht in `sabotage-pack.outcomes`.

| Item | Rezept |
|---|---|
| 2 Sabotagepakete | Papier + Fleisch + Spinnenauge + Schwarzpulver + Faden |
| Pflanzenmedizin | Glasflasche + Knochenmehl + Kräuter |
| Schädlingsspray | Glasflasche + Redstone + Fliegenpilz |
| Bodenkur | 2 Knochenmehl + Erde + Honigapfel |

## Discord-DMs

Fruchtwelt schickt Spielern, die mit CraftLink verknüpft sind (`/discord link`), private Nachrichten über
**deinen CraftLink-Bot**: bei Sabotage, kaputter Pflanze, reifer Pflanze (höchstens alle 15 Minuten) und wenn
man in der Anbauzone ausgeraubt wurde. Einrichten musst du nichts – Fruchtwelt liest Token und Verknüpfungen
aus `plugins/CraftLink`. Jeder Spieler kann mit `/fw dm` einzelne DMs an- und ausschalten.

## PvP in der Anbauzone

Wer in der Anbauzone einen Spieler tötet, nimmt 50 % seiner Substanzen und Samen mit
(`grow-zone.pvp-loot-percent`). Das gilt, wenn bei euch das Inventar beim Tod erhalten bleibt –
sonst fällt sowieso alles auf den Boden.

## 6. Menschen heilen und Shop (Drug_City)

Läuft automatisch in der Welt **Drug_City** (Name in `npcs.auto.world`):

- Sobald jemand dort ist, stellt das Plugin 15 Patienten, einen Shop-NPC und einen Händler um den Spawn auf.
- Der **Händler** kauft Substanzen gegen Heldenpunkte an (Preise: `sell-price` bei jeder Substanz).
- Patienten werden zufällig krank. Über dem Kopf steht, was hilft (z. B. Schmerzmittel oder Kräuter).
  Item in die Hand, NPC anklicken → geheilt, Heldenpunkte und der Effekt **Held des Dorfes**.
- **Jeder** darf heilen. Mit Held des Dorfes öffnet sich der Shop beim Shop-NPC.
- Shop-Stufen ab 5 / 30 / 100 Heilungen: Meisterbücher (bis Effizienz 10, Haltbarkeit 10, Schärfe 10),
  Erdbrecher (3x3), Holzfäller-Axt, Rubinschwert, Dünger.

Zum Testen: `/fw npc krank` macht sofort alle Patienten krank.

## 7. Befehle

| Befehl | Wer |
|---|---|
| `/fw buch`, `/fw distrikt`, `/fw taler`, `/fw stats [Spieler]`, `/fw saison`, `/fw dm` | alle |
| `/fw distrikt setzen <spieler> <A\|B\|C\|auto>`, `/fw distrikt info <spieler>` | Admin |
| `/fw give <spieler> <item> [anzahl]`, `/fw npc spawn\|entfernen\|krank` | Admin |
| `/fw taler <add\|set\|remove> <spieler> <betrag>`, `/fw heilungen <spieler> <zahl>`, `/fw reload` | Admin |

## 8. Discord

Webhook-Link bei `discord.webhook-url` eintragen, dann kommen Anti-Dünger-Angriffe und Shop-Freischaltungen in den
Kanal. Für CraftLink stehen die Events im Paket `dev.fruchtwelt.api` bereit.

- **3.2.1**: NPCs gezielt löschen: `/fw npc entfernen` (angeschauter NPC), `… alle`, `… <typ>`, `… dealer <substanz>`, `… umkreis <blöcke>`, `… name <name>`; gelöschte City-NPCs bleiben weg (gespeichert in `npcs.yml`) bis `/fw npc wiederherstellen`. `/fw npc liste`. Admin-NPCs verschwinden nicht mehr nach ein paar Sekunden. Neue Config-Einträge sind nach `/fw reload` sofort aktiv.
- **3.2.1**: Prestige-Spitzhacke ist jetzt Netherit-Basis (Gold konnte Eisen, Diamant, Redstone usw. nicht abbauen und droppte nichts). Alte Config und vorhandene Spitzhacken werden automatisch umgestellt.
- **3.2.1**: Ressourcenpaket erweitert (73 Modelle): Dünger, Anti-Dünger, Jägerbogen (mit Spann-Animation), Meisterbücher (je Verzauberung eigene Farbe), alle Konzept-Substanzen und ihre Samen. Neuer SHA1 siehe config.yml.
